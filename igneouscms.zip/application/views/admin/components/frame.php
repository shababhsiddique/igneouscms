<div class="row">
    <div class="col-lg-12">
        <div id="iframe_wrapper_div" class="responsive-iframe-container">          
            <iframe id="iframe_live"
                    scrolling="yes" 
                    name="inner_browser" 
                    src="<?php echo $url ?>"
                    frameborder="0" 
                    width="100%"                    
                    marginwidth="0"
                    marginheight="0"
                    ></iframe>
        </div>
    </div>
</div>

